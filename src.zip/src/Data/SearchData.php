<?php


namespace App\Data;


class SearchData
{
    /**
     * @var int
     */
    public $page = 1;

    /**
     * @var string
     */
    public $searchBarre = '';

    /**
     * @var bool
     */
    public $pro = true;

    /**
     * @var string
     */
    public $dateRapport = '';

    /**
     * @var string
     */
    public $dateMatch = '';

    /**
     * @var string
     */
    public $equipe1 = '';

    /**
     * @var string
     */
    public $equipe2 = '';

    /**
     * @var string
     */
    public $lieux = '';


}