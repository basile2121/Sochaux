<?php

namespace App\Form;

use App\Data\SearchData;
use App\Entity\RapportSpecifique;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\SearchType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use function Sodium\add;

class RapportsSearchType extends AbstractType {

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('searchBarre' , TextType::class , [
                'label' => 'Rechercher un rapport pour le Joueur',
                'required' => false,
                'attr' => [
                    'placeholder' => 'Entrer le nom du Joueur '
                ]
            ])
            ->add('dateRapport' , TextType::class , [
                'label' => 'Date du rapport  (YYYY-MM-DD)',
                'required' => false,
                'attr' => [
                    'placeholder' => 'Entrer une date '
                ]


            ])
        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => SearchData::class,
            'method' => 'GET',
            'csrf_protection' => false,
            "allow_extra_fields" => true
            ]);


    }

    public function getBlockPrefix()
    {
       return '';
    }
}